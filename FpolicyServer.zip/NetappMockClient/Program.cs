﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace NetappMockClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            //SynchronousSocketClient.StartClient();
            SynchronousSocketClient client = new SynchronousSocketClient();
            client.StartClient();



        }
    }

    public class SynchronousSocketClient
    {

        public static string headerstring = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Header><NotfType>NEGO_REQ</NotfType><ContentLen>250</ContentLen><DataFormat>XML</DataFormat></Header>\n\n";//+Environment.NewLine;
        public static string handshakerequeststring = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><Handshake><VsUUID>5fd3260c-00af-11e2-b1a6-123478563412</VsUUID><PolicyName>pol0</PolicyName><SessionId>74b09629-d4ae-11e1-aea3-12378563412</SessionId><ProtVersion><Vers>1.0</Vers></ProtVersion></Handshake>\0";

        private bool _isConnected;
        private Socket fPolicySocket = null;

        public void StartClient()
        {
            try
            {
                byte[] bytes = new byte[1024];

                while (Connect())
                {
                    KeepAlive keepAlive = new KeepAlive();
                    FileNotficationRequest fileNotficationRequest = new FileNotficationRequest();

                    //var requestBytes = Encoding.UTF8.GetBytes(keepAlive.ToXMLString());
                    //var lengthinBytes = BitConverter.GetBytes(requestBytes.Length);

                    var requestBytes = Encoding.UTF8.GetBytes(fileNotficationRequest.ToXMLString());
                    var lengthinBytes = BitConverter.GetBytes(requestBytes.Length);

                    Array.Reverse(lengthinBytes);
                    var msg = new byte[6 + requestBytes.Length];
                    msg[0] = 34;
                    msg[5] = 34;

                    Buffer.BlockCopy(lengthinBytes, 0, msg, 1, lengthinBytes.Length);
                    Buffer.BlockCopy(requestBytes, 0, msg, 6, requestBytes.Length);

                    // Send the data through the socket.  
                    int bytesSent = fPolicySocket.Send(msg);

                    // Receive the response from the remote device.  
                    int bytesRec = fPolicySocket.Receive(bytes);
                    Console.WriteLine("Echoed test = {0}", Encoding.ASCII.GetString(bytes, 0, bytesRec));

                }
            }
            catch (ArgumentNullException ane)
            {
                Console.WriteLine("ArgumentNullException : {0}", ane.ToString());
            }
            catch (SocketException se)
            {
                Console.WriteLine("SocketException : {0}", se.ToString());
            }
            catch (Exception e)
            {
                Console.WriteLine("Unexpected exception : {0}", e.ToString());
            }
        }
        public static void StartClient2()
        {

            //MessageHeader messageHeader = new MessageHeader(MessageHeader.NotfTypeEnum.NEGO_REQ, 250);
            //Console.WriteLine(messageHeader.ToXMLString());
            //Console.WriteLine(headerstring);

            //HandshakeRequest handshakeRequest = new HandshakeRequest("5fd3260c-00af-11e2-b1a6-123478563412", "pol0", "74b09629-d4ae-11e1-aea3-12378563412");
            //Console.WriteLine(handshakeRequest.ToXMLString());
            //Console.WriteLine(handshakerequeststring);
            //Console.ReadLine();

            // Data buffer for incoming data.  
            byte[] bytes = new byte[1024];

            // Connect to a remote device.  
            try
            {
                HandshakeRequest handshakeRequest = new HandshakeRequest("5fd3260c-00af-11e2-b1a6-123478563412", "pol0", "74b09629-d4ae-11e1-aea3-12378563412");
                string request = handshakeRequest.ToXMLString();
                //var requestBytes = Encoding.ASCII.GetBytes(request);

                var requestBytes = Encoding.UTF8.GetBytes(request);
                var lengthinBytes = BitConverter.GetBytes(requestBytes.Length);
                Array.Reverse(lengthinBytes);
                byte[] msg = new byte[6 + requestBytes.Length];
                msg[0] = 34;
                msg[5] = 34;

                Buffer.BlockCopy(lengthinBytes, 0, msg, 1, lengthinBytes.Length);
                Buffer.BlockCopy(requestBytes, 0, msg, 6, requestBytes.Length);

                // Establish the remote endpoint for the socket.  
                IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
                IPAddress ipAddress = ipHostInfo.AddressList[1];
                IPEndPoint remoteEP = new IPEndPoint(ipAddress, 6789);

                try
                {
                    Socket sender = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                    sender.Connect(remoteEP);
                    Console.WriteLine("Socket connected to {0}", sender.RemoteEndPoint.ToString());

                    int bytesSent = sender.Send(msg);
                    int bytesRec = sender.Receive(bytes);
                    Console.WriteLine("Echoed test = {0}", Encoding.ASCII.GetString(bytes, 0, bytesRec));

                    sender.Shutdown(SocketShutdown.Both);
                    sender.Close();
                }
                catch (SocketException se)
                {
                    Console.WriteLine("SocketException : {0}", se.ToString());
                }

                while (true)
                {
                    // Create a TCP/IP  socket.  
                    Socket sender = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                    //Socket sender = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Unspecified);
                    // Connect the socket to the remote endpoint. Catch any errors.  
                    try
                    {
                        sender.Connect(remoteEP);
                        Console.WriteLine("Socket connected to {0}", sender.RemoteEndPoint.ToString());

                        KeepAlive keepAlive = new KeepAlive();
                        //string request = handshakeRequest.ToXMLString();
                        //var requestBytes = Encoding.ASCII.GetBytes(request);
                        requestBytes = Encoding.UTF8.GetBytes(keepAlive.ToXMLString());
                        lengthinBytes = BitConverter.GetBytes(requestBytes.Length);
                        
                        Array.Reverse(lengthinBytes);
                        msg = new byte[6 + requestBytes.Length];
                        msg[0] = 34;
                        msg[5] = 34;

                        Buffer.BlockCopy(lengthinBytes, 0, msg, 1, lengthinBytes.Length);
                        Buffer.BlockCopy(requestBytes, 0, msg, 6, requestBytes.Length);

                        //var headerBytes = Encoding.ASCII.GetBytes(headerstring);
                        //var bodyBytes = Encoding.ASCII.GetBytes(handshakerequeststring);

                        //byte[] msg = Encoding.ASCII.GetBytes(command);
                        //int length = headerBytes.Length + bodyBytes.Length;
                        //int length = headerBytes.Length + bodyBytes.Length;
                        //var lengthinBytes = BitConverter.GetBytes(length);
                        //Array.Reverse(lengthinBytes);
                        // byte[] msg = new byte[6 + length];
                        // msg[0] = 34;
                        // msg[5] = 34;
                        //Buffer.BlockCopy(lengthinBytes, 0, msg, 6-lengthinBytes.Length, lengthinBytes.Length);
                        //Buffer.BlockCopy(lengthinBytes, 0, msg, 1, lengthinBytes.Length);
                        //Buffer.BlockCopy(headerBytes, 0, msg, 6, headerBytes.Length);
                        //Buffer.BlockCopy(bodyBytes, 0, msg, headerBytes.Length+6, bodyBytes.Length);
                        //msg[5] = null;

                        // Send the data through the socket.  
                         int bytesSent = sender.Send(msg);

                        // Receive the response from the remote device.  
                        int bytesRec = sender.Receive(bytes);
                        Console.WriteLine("Echoed test = {0}", Encoding.ASCII.GetString(bytes, 0, bytesRec));


                        // Release the socket.  
                        sender.Shutdown(SocketShutdown.Both);
                        sender.Close();

                    }
                    catch (ArgumentNullException ane)
                    {
                        Console.WriteLine("ArgumentNullException : {0}", ane.ToString());
                    }
                    catch (SocketException se)
                    {
                        Console.WriteLine("SocketException : {0}", se.ToString());
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Unexpected exception : {0}", e.ToString());
                    }
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        public bool Connect()
        {
            if (fPolicySocket != null) return true;

            byte[] bytes = new byte[1024];
            
            HandshakeRequest handshakeRequest = new HandshakeRequest("5fd3260c-00af-11e2-b1a6-123478563412", "pol0", "74b09629-d4ae-11e1-aea3-12378563412");
            string request = handshakeRequest.ToXMLString();
            var requestBytes = Encoding.UTF8.GetBytes(request);
            var lengthinBytes = BitConverter.GetBytes(requestBytes.Length);
            Array.Reverse(lengthinBytes);
            byte[] msg = new byte[6 + requestBytes.Length];
            msg[0] = 34;
            msg[5] = 34;
            Buffer.BlockCopy(lengthinBytes, 0, msg, 1, lengthinBytes.Length);
            Buffer.BlockCopy(requestBytes, 0, msg, 6, requestBytes.Length);

            // Establish the remote endpoint for the socket.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[1];
            IPEndPoint remoteEP = new IPEndPoint(ipAddress, 6789);
                        
            try
            {
                fPolicySocket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                fPolicySocket.Connect(remoteEP);
                Console.WriteLine("Socket connected to {0}", fPolicySocket.RemoteEndPoint.ToString());

                int bytesSent = fPolicySocket.Send(msg);
                int bytesRec = fPolicySocket.Receive(bytes);
                Console.WriteLine("Echoed test = {0}", Encoding.ASCII.GetString(bytes, 0, bytesRec));
                _isConnected = true;
                //fpolicyClient.Shutdown(SocketShutdown.Both);
                //fpolicyClient.Close();
            }
            catch (SocketException se)
            {
                Console.WriteLine("SocketException : {0}", se.ToString());
                _isConnected = false;                
            }
            return _isConnected;
        }

    }
}
