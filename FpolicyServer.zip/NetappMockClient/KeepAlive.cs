﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetappMockClient
{
    class KeepAlive
    {
        private MessageHeader messageHeader;

        public KeepAlive()
        {
            messageHeader = new MessageHeader(MessageHeader.NotfTypeEnum.KEEP_ALIVE, 0);
        }

        public string ToXMLString()
        {
            return messageHeader.ToXMLString() + "\0";
        }
    }
}
