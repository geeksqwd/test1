﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetappMockClient
{
    
    class FileNotfInfo
    {
        

        enum UserIdEnum
        {
            UNIX_ONLY,
            WIN_ONLY,
            MAPPED_ID
        }

        enum FileTypeEnum
        {
            FILE,
            DIR,
            STREAM,
            SYMLINK
        }

        enum PathNameEnum
        {
            WIN_NAME,
            WIN_8_3_NAME,
            UNIX_NAME
        }

        
        uint Uid = 0;
        string WinSid = String.Empty;
        uint UnixUid = 0;
        FileTypeEnum pathNameType = FileTypeEnum.FILE;
        string pathName = String.Empty;
        string clientIP = String.Empty;
        uint generationTime;
        UserIdEnum userIdtype = UserIdEnum.WIN_ONLY;


    }


    class FileNotficationRequest
    {
        string fileNotificationRequestXml = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><FscreenReq><ReqId>1234567</ReqId><ReqType>SMB_REN</ReqType><NotfInfo><SmbRenReq><CommonInfo><ProtCommonInfo><ClientIp>10.10.10.1</ClientIp><GenerationTime>9876543210</GenerationTime><UsrIdType>MAPPED_ID</UsrIdType><UsrContext><WinSid>administrator</WinSid></UsrContext><FileOwner><UnixUid>0</UnixUid></FileOwner><AccessPath><Path><PathNameType>WIN_NAME</PathNameType><PathName>\\FILE1.TXT</PathName></Path><Path><PathNameType>UNIX_NAME</PathNameType><PathName>/FILE1.TXT</PathName></Path></AccessPath><VolMsid>2227774443</VolMsid><FileSize>5</FileSize><NumHardLnk>1</NumHardLnk><IsOfflineAttr>0</IsOfflineAttr><FileType>FILE</FileType><IsSparse>0</IsSparse><IsDense>0</IsDense></ProtCommonInfo><DisplayPath>-</DisplayPath><ProtVer><MajorNum>2</MajorNum><MinorNum>1</MinorNum></ProtVer></CommonInfo><TargetAccessPath><Path><PathNameType>WIN_NAME</PathNameType><PathName>\\FILE1RENAMED.TXT</PathName></Path><Path><PathNameType>UNIX_NAME</PathNameType><PathName>/FILE1RENAMED.TXT</PathName></Path></TargetAccessPath></SmbRenReq></NotfInfo></FscreenReq>";

        //The UUID of the vserver in which fpolicy is enabled.
        private UInt32 _ReqId = 0;
        private ReqTypeEnum _ReqType = ReqTypeEnum.SMB_OPEN;
        private FileNotfInfo  _fileNotfInfo ;

        private MessageHeader messageHeader;

        public enum ReqTypeEnum
        {
            SMB_OPEN,
            SMB_CLOSE,
            SMB_CREAT,
            SMB_CREAT_DIR,
            SMB_DEL,
            SMB_DEL_DIR,
            SMB_REN,
            SMB_REN_DIR,
            SMB_GET_ATTR,
            SMB_SET_ATTR,
            SMB_RD,
            SMB_WR,
            NFS_LOOKUP,
            NFS_CREAT,
            NFS_CREAT_DIR,
            NFS_DEL,
            NFS_DEL_DIR,
            NFS_REN,
            NFS_REN_DIR,
            NFS_OPEN,
            NFS_CLOSE,
            NFS_RD,
            NFS_WR,
            NFS_GET_ATTR,
            NFS_SET_ATTR,
            NFS_LNK,
            NFS_SYM_LNK
        }

       

        public UInt32 ReqId { get => _ReqId; set => _ReqId = value; }
        //public string ReqType { get => _ReqType; set => _ReqType = value; }
       
        public FileNotficationRequest()
        {
            //VsUUID = Guid.NewGuid().ToString();
            //PolicyName = "pol0";
            //SessionId = Guid.NewGuid().ToString();
        }

        public FileNotficationRequest(String vsUUID, String policyName, String sessionId)
        {
            //VsUUID = vsUUID;
            //PolicyName = policyName;
            //SessionId = sessionId;
        }


        public string ToXMLString()
        {
            //StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?><FscreenReq><ReqId>");
            //sb.Append(VsUUID);
            //sb.Append("</ReqId><ReqType>");
            //sb.Append(PolicyName);
            //sb.Append("</ReqType><NotfInfo>");
            //sb.Append(SessionId);
            //sb.Append("</NotfInfo></FscreenReq>");
            //messageHeader = new MessageHeader(MessageHeader.NotfTypeEnum.NEGO_REQ, sb.Length);
            //return messageHeader.ToXMLString() + "\n\n" + sb.ToString() + "\0";

            StringBuilder sb = new StringBuilder(fileNotificationRequestXml);
            messageHeader = new MessageHeader(MessageHeader.NotfTypeEnum.SCREEN_REQ, sb.Length);
            return messageHeader.ToXMLString() + "\n\n" + sb.ToString() + "\0";
        }
    }
}
