﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/**
 * Represents the HandshakeRequestBody
 * "<?xml version=\"1.0\" encoding=\"utf-8\" ?>
 * <Handshake>
 *      <VsUUID>5fd3260c-00af-11e2-b1a6-123478563412</VsUUID>
 *      <PolicyName>pol0</PolicyName>
 *      <SessionId>74b09629-d4ae-11e1-aea3-12378563412</SessionId>
 *      <ProtVersion>
 *          <Vers>1.0</Vers>
 *      </ProtVersion>
 * </Handshake>
 */


namespace NetappMockClient
{
    class HandshakeRequest
    {
        //The UUID of the vserver in which fpolicy is enabled.
        private string _VsUUID = String.Empty;
        private string _PolicyName = String.Empty;
        private string _SessionId = String.Empty;
        private const string _ver = "1.0";
        private MessageHeader messageHeader;

        public string VsUUID { get => _VsUUID; set => _VsUUID = value; }
        public string PolicyName { get => _PolicyName; set => _PolicyName = value; }
        public string SessionId { get => _SessionId; set => _SessionId = value; }

        public static string ProtVersion => _ver;

        public HandshakeRequest() {
            VsUUID = Guid.NewGuid().ToString();
            PolicyName = "pol0";
            SessionId = Guid.NewGuid().ToString();                      
        }

        public HandshakeRequest(String vsUUID, String policyName, String sessionId)
        {
            VsUUID = vsUUID;
            PolicyName = policyName;
            SessionId = sessionId;
        }



        public string ToXMLString()
        {
            StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?><Handshake><VsUUID>");
            sb.Append(VsUUID);
            sb.Append("</VsUUID><PolicyName>");
            sb.Append(PolicyName);
            sb.Append("</PolicyName><SessionId>");
            sb.Append(SessionId);
            sb.Append("</SessionId><ProtVersion><Vers>1.0</Vers></ProtVersion></Handshake>");
            messageHeader = new MessageHeader(MessageHeader.NotfTypeEnum.NEGO_REQ, sb.Length);
            return messageHeader.ToXMLString() + "\n\n" + sb.ToString() + "\0";
        }


    }
}
