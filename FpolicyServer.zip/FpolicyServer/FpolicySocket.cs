﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace FpolicyServer
{
    class FpolicySocket
    {
        // Incoming data from the client.  
        public static string data = null;
        static Socket serverSocket;
        private const int BUFFER_SIZE = 4096;
        private static byte[] buffer = new byte[BUFFER_SIZE]; //buffer size is limited to BUFFER_SIZE per message
        const int MAX_RECEIVE_ATTEMPT = 10;
        static int receiveAttempt = 0; //this is not fool proof, obviously, since actually you must have multiple of this for multiple clients, but for the sake of simplicity I put this

        public static void StartListening(int PORT_NO)
        {         
            serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            serverSocket.Bind(new IPEndPoint(IPAddress.Any, PORT_NO));
            serverSocket.Listen(4); //the maximum pending client, define as you wish
            serverSocket.BeginAccept(new AsyncCallback(acceptCallback), null);
        }

        private static void acceptCallback(IAsyncResult result)
        { 
            //if the buffer is old, then there might already be something there...
            Socket socket = null;
            try
            {
                socket = serverSocket.EndAccept(result); // The objectDisposedException will come here... thus, it is to be expected!
                //Do something as you see it needs on client acceptance
                socket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, new AsyncCallback(receiveCallback), socket);
                serverSocket.BeginAccept(new AsyncCallback(acceptCallback), null); //to receive another client
            }
            catch (Exception e)
            { // this exception will happen when "this" is be disposed...        
                //Do something here             
                Console.WriteLine(e.ToString());
            }
        }

        private static void receiveCallback(IAsyncResult result)
        {
            Socket socket = null;
            try
            {
                socket = (Socket)result.AsyncState; //this is to get the sender
                if (socket.Connected)
                { //simple checking
                    int received = socket.EndReceive(result);
                    if (received > 0)
                    {
                        byte[] data = new byte[received-6]; //the data is in the byte[] format, not string!
                        byte[] messageSize = new byte[4];
                        
                        Buffer.BlockCopy(buffer, 1, messageSize, 0, messageSize.Length); //There are several way to do this according to http://stackoverflow.com/questions/5099604/any-faster-way-of-copying-arrays-in-c in general, System.Buffer.memcpyimpl is the fastest
                        Buffer.BlockCopy(buffer, 6, data, 0, data.Length);

                        String dataString = Encoding.UTF8.GetString(data);
                        byte[] replyBytes = processRecievedData(dataString);

                        Console.WriteLine(dataString);
                        if (replyBytes != null)
                        {
                            Console.WriteLine(DateTime.Now + ": replying with " + replyBytes.Length + " bytes");

                            //Message retrieval part
                            //Suppose you only want to declare that you receive data from a client to that client

                            socket.Send(replyBytes);
                        }

                        receiveAttempt = 0; //reset receive attempt
                        socket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, new AsyncCallback(receiveCallback), socket); //repeat beginReceive
                    }
                    else if (receiveAttempt < MAX_RECEIVE_ATTEMPT)
                    { //fail but not exceeding max attempt, repeats
                        ++receiveAttempt; //increase receive attempt;
                        socket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, new AsyncCallback(receiveCallback), socket); //repeat beginReceive
                    }
                    else
                    { //completely fails!
                        Console.WriteLine("receiveCallback fails!"); //don't repeat beginReceive
                        receiveAttempt = 0; //reset this for the next connection
                    }
                }
            }
            catch (Exception e)
            { // this exception will happen when "this" is be disposed...
                Console.WriteLine("receiveCallback fails with exception! " + e.ToString());
            }
        }

        private static byte[] processRecievedData(string dataString)
        {
            string responseString = String.Empty;
            //string[] dataStringArray = dataString.Split('\n');
            string[] dataStringArray = dataString.Split(new string[] { "\n\n" }, StringSplitOptions.None);
            if (dataStringArray.Length != 2)
            {
                //return error
                return null;
            }
            XmlDocument headerDoc = new XmlDocument();
            headerDoc.LoadXml(dataStringArray[0]);
            string notificationType = headerDoc.GetElementsByTagName("NotfType")[0].InnerText;

            switch (notificationType) {
                case "NEGO_REQ":
                    responseString = ParseHandshakeRequest(dataStringArray[1]);
                    break;
                case "ALERT_MSG":
                    // notfReponse = "Handshake, Failed with fatal error!";
                    responseString = ParseAlert(dataStringArray[1]);
                    break;
                case "SCREEN_REQ":
                    responseString = ParseScreenRequest(dataStringArray[1]);
                    break;
                case "STATUS_QUERY_REQ":
                    // notfReponse = "Did the query get stuck?";
                    responseString = ParseStatusRequest(dataStringArray[1]);
                    break;
                case "SCREEN_CANCEL":
                    //  notfReponse = "Cancel the request handling!!";
                    break;
                case "KEEP_ALIVE":
                    break;
                default:
                    //unimplemented yet;
                    break;
            }

            if (responseString != null)
            {
                var requestBytes = Encoding.UTF8.GetBytes(responseString);
                var lengthinBytes = BitConverter.GetBytes(requestBytes.Length);
                Array.Reverse(lengthinBytes);
                byte[] msg = new byte[6 + requestBytes.Length];
                msg[0] = 34;
                msg[5] = 34;
                Buffer.BlockCopy(lengthinBytes, 0, msg, 1, lengthinBytes.Length);
                Buffer.BlockCopy(requestBytes, 0, msg, 6, requestBytes.Length);

                return msg;
            }

            return null;
        }

        private static string ParseAlert(string AlertMessageString)
        {
            string SessionId = String.Empty;
            string Severity = String.Empty;
            string AlertMsg = String.Empty;

            
            XmlDocument headerDoc = new XmlDocument();
            headerDoc.LoadXml(AlertMessageString);
            SessionId = headerDoc.GetElementsByTagName("SessionId")[0].InnerText;
            Severity = headerDoc.GetElementsByTagName("Severity")[0].InnerText;
            AlertMsg = headerDoc.GetElementsByTagName("AlertMsg")[0].InnerText;

            Console.WriteLine("Error recieved from fpolicy client: " + AlertMsg);

            return null;
        }

        private static string ParseStatusRequest(string statusRequestString)
        {
            string ReqId = String.Empty;
            string ReqType = String.Empty;

            string Resp = "1"; //always return that we are working on the request

            XmlDocument headerDoc = new XmlDocument();
            headerDoc.LoadXml(statusRequestString);
            ReqId = headerDoc.GetElementsByTagName("ReqId")[0].InnerText;
            ReqType = headerDoc.GetElementsByTagName("ReqType")[0].InnerText;

            StringBuilder sb = new StringBuilder();
            sb.Append("<?xml version=\"1.0\"?><FscreenStatusResp><ReqId>");
            sb.Append(ReqId);
            sb.Append("</ReqId><ReqType>");
            sb.Append(ReqType);
            sb.Append("</ReqType><Resp>");
            sb.Append(Resp);
            sb.Append("</Resp></FscreenStatusResp>");

            MessageHeader messageHeader = new MessageHeader(MessageHeader.NotfTypeEnum.NEGO_RESP, sb.Length);

            return messageHeader.ToXMLString() + "\n\n" + sb.ToString() + "\0";
        }

        private static string ParseScreenRequest(string requestString)
        {
            //<?xml version=\"1.0\" encoding=\"utf-8\" ?><FscreenReq><reqId>1234567</reqId><reqType>SMB_REN</reqType><NotfInfo><SmbRenReq><CommonInfo><ProtCommonInfo><ClientIp>10.10.10.1</ClientIp><GenerationTime>9876543210</GenerationTime><UsrIdType>MAPPED_ID</UsrIdType><UsrContext><WinSid>administrator</WinSid></UsrContext><FileOwner><UnixUid>0</UnixUid></FileOwner><AccessPath><Path><PathNameType>WIN_NAME</PathNameType><PathName>\\FILE1.TXT</PathName></Path><Path><PathNameType>UNIX_NAME</PathNameType><PathName>/FILE1.TXT</PathName></Path></AccessPath><VolMsid>2227774443</VolMsid><FileSize>5</FileSize><NumHardLnk>1</NumHardLnk><IsOfflineAttr>0</IsOfflineAttr><FileType>FILE</FileType><IsSparse>0</IsSparse><IsDense>0</IsDense></ProtCommonInfo><DisplayPath>-</DisplayPath><ProtVer><MajorNum>2</MajorNum><MinorNum>1</MinorNum></ProtVer></CommonInfo><TargetAccessPath><Path><PathNameType>WIN_NAME</PathNameType><PathName>\\FILE1RENAMED.TXT</PathName></Path><Path><PathNameType>UNIX_NAME</PathNameType><PathName>/FILE1RENAMED.TXT</PathName></Path></TargetAccessPath></SmbRenReq></NotfInfo></FscreenReq>
            /**
            *   cout << "A file notification came with the following characteristics:\n";
            * cout << "Operation type: " << Extract_tag_value(notfBody, "ReqType") << endl;
            * cout << "Client IP: " << Extract_tag_value(notfBody, "ClientIp") << endl;
            * cout << "File path: " << Extract_tag_value(notfBody, "DisplayPath") << endl;
            * notfReponse = Parse_response(notfType, notfHeader, notfBody);
            */

            string reqId = String.Empty;
            string reqType = String.Empty;
            string ClientIp = String.Empty;
            string DisplayPath = String.Empty;

            XmlDocument headerDoc = new XmlDocument();
            headerDoc.LoadXml(requestString);
            reqId = headerDoc.GetElementsByTagName("ReqId")[0].InnerText;
            reqType = headerDoc.GetElementsByTagName("ReqType")[0].InnerText;
            ClientIp = headerDoc.GetElementsByTagName("ClientIp")[0].InnerText;
            DisplayPath = headerDoc.GetElementsByTagName("DisplayPath")[0].InnerText;

            StringBuilder sb = new StringBuilder();
            sb.Append("<?xml version=\"1.0\"?><FscreenResp><ReqId>");
            sb.Append(reqId);
            sb.Append("</ReqId><ReqType>");
            sb.Append(reqType);
            sb.Append("</ReqType><NotfResp>");
            sb.Append("1");
            sb.Append("</NotfResp></FscreenResp>");

            MessageHeader messageHeader = new MessageHeader(MessageHeader.NotfTypeEnum.SCREEN_RESP, sb.Length);

            return messageHeader.ToXMLString() + "\n\n" + sb.ToString() + "\0";
        }

        private static string ParseHandshakeRequest(string handshakeString)
        {
            //<?xml version="1.0" encoding="utf-8"?><Handshake><VsUUID>5fd3260c-00af-11e2-b1a6-123478563412</VsUUID><PolicyName>pol0</PolicyName><SessionId>74b09629-d4ae-11e1-aea3-12378563412</SessionId><ProtVersion><Vers>1.0</Vers></ProtVersion></Handshake>
            string VsUUID = String.Empty;
            string PolicyName = String.Empty;
            string SessionId = String.Empty;
            string ProtVersion = String.Empty;

            XmlDocument headerDoc = new XmlDocument();
            headerDoc.LoadXml(handshakeString);
            VsUUID = headerDoc.GetElementsByTagName("VsUUID")[0].InnerText;
            PolicyName = headerDoc.GetElementsByTagName("PolicyName")[0].InnerText;
            SessionId = headerDoc.GetElementsByTagName("SessionId")[0].InnerText;
            ProtVersion = headerDoc.GetElementsByTagName("ProtVersion")[0].InnerText;

            StringBuilder sb = new StringBuilder();
            sb.Append("<?xml version=\"1.0\"?><HandshakeResp><VsUUID>");
            sb.Append(VsUUID);
            sb.Append("</VsUUID><PolicyName>");
            sb.Append(PolicyName);
            sb.Append("</PolicyName><SessionId>");
            sb.Append(SessionId);
            sb.Append("</SessionId><ProtVersion><Vers>");
            sb.Append(ProtVersion);
            sb.Append("</Vers></ProtVersion></HandshakeResp>");
            
            MessageHeader messageHeader = new MessageHeader(MessageHeader.NotfTypeEnum.NEGO_RESP, sb.Length);
            
            return messageHeader.ToXMLString() + "\n\n" + sb.ToString() + "\0";            
        }

        public void StartListening(int port,int stam)
        {
            // Data buffer for incoming data.  
            byte[] bytes = new Byte[1024];

            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, port);

            // Create a TCP/IP socket.  
            Socket listener = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            // Bind the socket to the local endpoint and
            // listen for incoming connections.  
            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                // Start listening for connections.  
                while (true)
                {
                    Console.WriteLine("Waiting for a connection...");
                    // Program is suspended while waiting for an incoming connection.  
                    Socket handler = listener.Accept();
                    data = null;

                    // An incoming connection needs to be processed.  
                    while (true)
                    {
                        int bytesRec = handler.Receive(bytes);
                        data += Encoding.UTF8.GetString(bytes, 0, bytesRec);
                        if (data.IndexOf("<EOF>") > -1)
                        {
                            break;
                        }
                    }

                    // Show the data on the console.  
                    Console.WriteLine("Text received : {0}", data);

                    // Echo the data back to the client.  
                    byte[] msg = Encoding.UTF8.GetBytes(data);

                    handler.Send(msg);
                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();

        }
    }
}
