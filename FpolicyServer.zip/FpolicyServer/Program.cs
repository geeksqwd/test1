﻿using System;

namespace FpolicyServer
{
    class Program
    {

        //static void Main(string[] args)
        //{
        //    int listeningPort = 0;
        //    Console.WriteLine("Hello World!");
        //    FpolicySocket fpolicySocket = new FpolicySocket();
        //    fpolicySocket.StartListening(listeningPort);
        //    Console.ReadLine();
        //}

        const int PORT_NO = 6789;
        const string SERVER_IP = "127.0.0.1";
       
        static void Main(string[] args)
        {
            //---listen at the specified IP and port no.---
            Console.WriteLine("Listening...");

            //FpolicySocket fpolicySocket = new FpolicySocket();
            //fpolicySocket.StartListening(PORT_NO);

            FpolicySocket.StartListening(PORT_NO);
            string result = "";
            do
            {
                result = Console.ReadLine();
            } while (result.ToLower().Trim() != "exit");
        }
    }
}
