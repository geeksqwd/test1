﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * represents the Header XML
 * <?xml version=1.0?>
 * <Header>
 *    <NotfType>NEGO_REQ</NotfType>
 *	  <ContentLen>250</ContentLen>
 *	  <DataFormat>XML</DataFormat>
 * </Header>
*/

namespace FpolicyServer
{
    public class MessageHeader
    {
        //Only XML currently supported
        private const string _DataFormat = "XML";
        public string DataFormat { get => _DataFormat; }

        private int _ContentLen = 0;
        public int ContentLen { get => _ContentLen; set => _ContentLen = value; }

        private NotfTypeEnum _NotfType = NotfTypeEnum.KEEP_ALIVE; 
        public NotfTypeEnum NotfType { get => _NotfType; set => _NotfType = value; }

        public enum NotfTypeEnum
        {
            NEGO_REQ,
            NEGO_RESP,
            SCREEN_REQ,
            SCREEN_RESP,
            VOL_NOTIFICATION,
            SCREEN_CANCEL,
            STATUS_QUERY_REQ,
            STATUS_QUERY_RESP,
            BACK_PRESSURE_APPLY,
            BACK_PRESSURE_REM,
            KEEP_ALIVE,
            ALERT_MSG,
            OUTAGE_MSG
        }

        public MessageHeader()
        {
            NotfType = NotfTypeEnum.KEEP_ALIVE;
            ContentLen = 0;
        }

        public MessageHeader(NotfTypeEnum notificationType, int contentLength)
        {
            NotfType = notificationType;
            ContentLen = contentLength;
        }

        public string ToXMLString()
        {
            StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?><Header><NotfType>");
            sb.Append(NotfType);
            sb.Append("</NotfType><ContentLen>");
            sb.Append(ContentLen);
            sb.Append("</ContentLen><DataFormat>XML</DataFormat></Header>");
            return sb.ToString();
        }


    }
}
